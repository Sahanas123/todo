package com.example.codsofttodoapp;

import android.content.DialogInterface;

public interface ToDoDialogCloseListener {
    public void handleDialogClose(DialogInterface dialog);
}
